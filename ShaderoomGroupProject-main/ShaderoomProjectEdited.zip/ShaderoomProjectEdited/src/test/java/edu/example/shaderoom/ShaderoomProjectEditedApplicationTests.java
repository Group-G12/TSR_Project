package edu.example.shaderoom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShaderoomProjectEditedApplicationTests {

    @Test
    void contextLoads() {
    }

}
